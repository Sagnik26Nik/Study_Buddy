import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:study_buddy/views/Profile.dart';

class MembersPage extends StatefulWidget {
  final String studyGroupId;

  MembersPage({required this.studyGroupId});

  @override
  _MembersPageState createState() => _MembersPageState();
}

class _MembersPageState extends State<MembersPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,  // Set background to black
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          "Members",
          style: TextStyle(color: Colors.orange),  // Orange text for the title
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore
            .collection('StudyGroups')
            .doc(widget.studyGroupId)
            .collection('members')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                "No members found",
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          var members = snapshot.data!.docs;


          return ListView.builder(
            itemCount: members.length,
            itemBuilder: (context, index) {
              var member = members[index];

              return GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => ProfilePage(uid: member['uid'],)));
                },
                child: Card(
                  color: Colors.black,  // Card background color
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16),
                    leading: CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.orange,
                      child: Text(
                        member['name'][0].toUpperCase(),
                        style: TextStyle(color: Colors.black, fontSize: 20),
                      ),
                    ),
                    title: Text(
                      member['name'],
                      style: TextStyle(
                        color: Colors.orange,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Major: ${member['major']}",
                          style: TextStyle(color: Colors.white),
                        ),
                        Text(
                          "University: ${member['university']}",
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
