import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:study_buddy/views/Chat.dart';
import 'package:study_buddy/views/Login.dart';

class ProfilePage extends StatefulWidget {
  late final uid;
  ProfilePage({
    required this.uid
  });
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  var isFriend=false;
 Map<String, dynamic>? conversationData;

  @override
  void initState() {
    super.initState();
     _fetchFriend();
  }

  Future<void> _fetchFriend() async {
    try {
      String? currentUserId = FirebaseAuth.instance.currentUser?.uid;

      if (currentUserId == null) {
        // Handle not logged in
        print("User not logged in.");
        return;
      }

      var snap = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.uid)
          .collection('conversations')
          .doc(currentUserId)
          .get();

      if (snap.exists) {
        setState(() {
          isFriend=true;
        });
      } else {
        print("No conversation found.");
      }
    } catch (e) {
      print("Error fetching conversation: $e");
    }
  }
  final TextEditingController aboutMeController = TextEditingController();
  var uid;
  final User? user = FirebaseAuth.instance.currentUser;
  var showabout = false;
  @override
  Widget build(BuildContext context) {
    uid = widget.uid;
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.orange),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            SizedBox(width: 10),
            Text("Profile", style: TextStyle(color: Colors.white)),
          ],
        ),
      ),
      body:StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('users').doc(uid == null ? user?.uid : uid).snapshots(),
          builder: (context, snapshot) {
            print(uid);
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }
            if (!snapshot.hasData || !snapshot.data!.exists) {
              return Center(child: Text("No profile data found", style: TextStyle(color: Colors.white)));
            }
            var userData = snapshot.data!.data() as Map<String, dynamic>;
            return Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      CircleAvatar(
                  backgroundColor: Colors.orange,
                  radius: width*0.1,
                  child: FutureBuilder<DocumentSnapshot>(
                        future: FirebaseFirestore.instance
                            .collection('users')
                            .doc(uid == null ? user?.uid : uid)
                            .get(),
                        builder: (context, currentUserSnapshot) {
                          if (!currentUserSnapshot.hasData) {
                            return Center(child: CircularProgressIndicator());
                          }
                          final currentUser = currentUserSnapshot.data!;
                          return Text(
                    currentUser['name'][0].toUpperCase(),
                    style: TextStyle(color: Colors.black, fontSize: width*0.1),
                  );
                        })
                ),
                      SizedBox(height: 10),
                      Text(userData['name'] ?? "No Name", 
                          style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                      Text(userData['email'] ?? "No Email", 
                          style: TextStyle(color: Colors.grey, fontStyle: FontStyle.italic)),
                      SizedBox(height: 10),
                      Row(children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text("About Me:", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                      if(uid==null)
                      IconButton(onPressed: 
                      ()
                      {
                        setState(() {
                          showabout = true;
                        });
                      }, icon: Icon(Icons.edit))
                      ]),
                      SizedBox(height: 5),
                      Text(
                        userData['aboutMe'] ?? "No description available",
                        style: TextStyle(color: Colors.grey),
                        textAlign: TextAlign.left,
                      ),
                    ],
                  ),
                ),
                if(uid!=null)
                IconButton(onPressed: ()
                async{
                    if (isFriend)
                    {
                      Navigator.push(
          context, MaterialPageRoute(builder: (context) => ChatPage()));
                    }
                    else{
                      var details = await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser?.uid).get();
                      FirebaseFirestore.instance.collection('users').doc(uid).collection('FriendRequests').doc(FirebaseAuth.instance.currentUser?.uid).set(
                        {

            "name":details['name'],
            "university":details['university']
            ,"major":details['major'],
            "uid":FirebaseAuth.instance.currentUser,                        
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text("Friend Request Sent")),
                                  );
                    }
                }, icon: Icon(isFriend?Icons.chat:Icons.add), color: Colors.orange,),
                if(uid!=null)
                Text(isFriend?'Chat': 'Add Friend',style: TextStyle(color: Colors.white),),
                SizedBox(height: 20),
                if(showabout)
                  SizedBox(height: 20),

                if(showabout)
                Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "About Me",
                            style: TextStyle(color: Colors.white70),
                          ),
                          SizedBox(height: 5),
                          TextField(
                            controller: aboutMeController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Enter description',
                              hintStyle: TextStyle(color: Colors.white54),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.orange),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.orange, width: 2),
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                          if(showabout)
                          Center(
                  child: Container(
                    height: height*0.05,
                    width: width*0.3,
                    margin: EdgeInsets.only(top: height*0.02),
                    decoration: BoxDecoration(color: Colors.orange,borderRadius: BorderRadius.circular(10)),
                    child: TextButton(
                      
                          
                              onPressed: () async {
                                String uid = FirebaseAuth.instance.currentUser!.uid; // Get current user UID
                                String aboutMe = aboutMeController.text.trim(); // Get the updated text

                                if (aboutMe.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text("Please enter something in About Me.")),
                                  );
                                  return;
                                }

                                try {
                                  await FirebaseFirestore.instance.collection("users").doc(uid).update({
                                    "aboutMe": aboutMe,
                                  });

                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text("About Me updated successfully!")),
                                  );
                                } catch (e) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text("Update Failed: ${e.toString()}")),
                                  );
                                }
                              },
                              child: Text('Update AboutMe'),
                            ),
                  ))

                        ],
                      ),
                    ),
                if(uid==null)
                buildButton(context, "Sign Out", null, Colors.red, Colors.white, isSignOut: true),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget buildButton(BuildContext context, String text, IconData? icon, Color color, Color textColor, {bool isSignOut = false}) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      child: TextButton(
        onPressed: isSignOut ? () async {
          await FirebaseAuth.instance.signOut();
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) =>LogInScreen()));
        } : () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(text, style: TextStyle(color: textColor, fontSize: 16)),
            if (icon != null) Icon(icon, color: Colors.blue),
          ],
        ),
      ),
    );
  }
}
