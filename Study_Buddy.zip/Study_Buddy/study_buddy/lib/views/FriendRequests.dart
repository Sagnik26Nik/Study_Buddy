import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:study_buddy/views/Profile.dart';

class FriendRequestsPage extends StatefulWidget {


  @override
  _FriendRequestsPageState createState() => _FriendRequestsPageState();
}

class _FriendRequestsPageState extends State<FriendRequestsPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Function to accept a friend request
  

  @override
  Widget build(BuildContext context) {
    var userId = FirebaseAuth.instance.currentUser?.uid;
     double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,  // Set background to black
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          "Friend Requests",
          style: TextStyle(color: Colors.orange),  // Orange text for the title
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore.collection('users').doc(FirebaseAuth.instance.currentUser?.uid)
            .collection('FriendRequests')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                "No friend requests",
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          var requests = snapshot.data!.docs;

          return ListView.builder(
            itemCount: requests.length,
            itemBuilder: (context, index) {
              var request = requests[index];

              return GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context, 
                    MaterialPageRoute(builder: (context) => ProfilePage(uid: request['uid'])),
                  );
                },
                child: Card(
                  color: Colors.black,  // Card background color
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16),
                    leading:CircleAvatar(
                  backgroundColor: Colors.orange,
                  radius: width*0.1,
                  child: Text(
                    request['name'][0].toUpperCase(),
                    style: TextStyle(color: Colors.black, fontSize: width*0.1),
                  
                      
                )),
                    title: Row(children: [Text(
                      request['name'].toUpperCase(),
                      style: TextStyle(
                        color: Colors.orange,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    Spacer(),  // This will push the buttons to the right
    // Accept Button
    ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.orange,  // Orange background
        foregroundColor: Colors.black, // Black text
      ),
      onPressed: () async{
        var myDetails = await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser?.uid).get();
        await FirebaseFirestore.instance.collection('users').doc(request['uid']).collection('conversations').doc(FirebaseAuth.instance.currentUser?.uid).set(
{
 "name":myDetails['name'],
            "university":myDetails['university']
            ,"major":myDetails['major'],
            "uid":myDetails['uid']
}
        );

        await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser?.uid).collection('conversations').doc(request['uid']).set(
{
 "name":request['name'],
            "university":request['university']
            ,"major":request['major'],
            "uid":request['uid']
}
        );
                await _firestore.collection('users').doc(FirebaseAuth.instance.currentUser?.uid).collection('FriendRequests').doc(request['uid']).delete();
ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Friend request accepted!')),
      );
      },
      child: Text("Accept"),
    ),
    SizedBox(width: 10), // Space between buttons
    // Reject Button
    ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.black,  // Black background
        foregroundColor: Colors.orange, // Orange text
      ),
      onPressed: () async{
        await _firestore.collection('users').doc(FirebaseAuth.instance.currentUser?.uid).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Friend request rejected!')),
      );
      },
      child: Text("Reject"),
    ),
                    ]),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Major: ${request['major']}",
                          style: TextStyle(color: Colors.white),
                        ),
                        Text(
                          "University: ${request['university']}",
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
