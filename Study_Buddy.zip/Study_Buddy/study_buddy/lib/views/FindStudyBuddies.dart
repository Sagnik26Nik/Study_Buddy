import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:study_buddy/views/FriendRequests.dart';
import 'package:study_buddy/views/Profile.dart';

class FindStudyBuddies extends StatefulWidget {
  @override
  State<FindStudyBuddies> createState() => _FindStudyBuddiesState();
}

class _FindStudyBuddiesState extends State<FindStudyBuddies> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _fetchConversation();
  }
  var reqCount=0;
  Future<void> _fetchConversation() async {
          String? currentUserId = FirebaseAuth.instance.currentUser?.uid;


     var snap = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUserId)
        .collection('FriendRequests')
        .get();

    setState(() {
      reqCount =  snap.docs.length;
    }); 
  }
  double getStringMatchScore(String source, String target) {
  // If either string is empty, there's no match
  if (source.isEmpty || target.isEmpty) return 0.0;

  source = source.toLowerCase();
  target = target.toLowerCase();

  // The longer the common substring, the higher the match score
  int commonChars = 0;

  for (int i = 0; i < source.length; i++) {
    if (target.contains(source[i])) {
      commonChars++;
    }
  }

  // Normalize the score between 0 and 1
  double score = commonChars / source.length;
  return score;
}
  var showSuggested = true;
  TextEditingController _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.orange),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Text("Find Study Buddies", style: TextStyle(color: Colors.white)),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Container(
                width: width*0.75,
                height: height*0.07,
                child: TextField(
                    style: TextStyle(color: Colors.white),
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: "Find your Buddies",
                    hintStyle: TextStyle(color: Colors.grey),
                    prefixIcon: Icon(Icons.search, color: Colors.grey),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.all(16),
                  ),
                ),
              ),
            ),
              IconButton(onPressed: ()
              {
                setState(() {
                  
                  showSuggested = false;
                });

              }, icon: Icon(Icons.search,color: Colors.orange,)),
              IconButton(onPressed: ()
              {
                _searchController.clear();
                setState(() {
                  
                showSuggested = true;
                                });

              }, icon: Icon(Icons.cancel,color: Colors.orange,)),
            ]),
            SizedBox(height: 16),
            Container(
              width: width*0.9,
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              child: GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => FriendRequestsPage()));
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Pending Requests", style: TextStyle(color: Colors.white)),
                    Row(
                      children: [
                        Text(reqCount.toString(), style: TextStyle(color: Colors.orange)),
                      ],
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),
            Text("Suggested", style: TextStyle(color: Colors.white, fontSize: 18)),
            SizedBox(height: 10),
            SingleChildScrollView(
              child: Container(
                width: width*0.9,
                height: height*0.6,
                child:  showSuggested==false?StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('users')
                      .where('uid', isNotEqualTo: FirebaseAuth.instance.currentUser?.uid)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }
                
                    if (snapshot.hasError) {
                      return Center(
                        child: Text(
                          'Error: ${snapshot.error}',
                          style: TextStyle(color: Colors.white),
                        ),
                      );
                    }
                
                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(
                        child: Text(
                          'No study buddies available.',
                          style: TextStyle(color: Colors.white),
                        ),
                      );
                    }
                
                    // Get the search query and convert to lower case
                    final query = _searchController.text.toLowerCase();
                
                    // Filter users based on the query string match score
                    final filteredUsers = snapshot.data!.docs
                        .map((doc) {
                          final name = doc['name'].toString();
                          final major = doc['major'].toString();
                          final university = doc['university'].toString();
                
                          // Calculate a score for each field
                          final nameMatch = getStringMatchScore(query, name);
                          final majorMatch = getStringMatchScore(query, major);
                          final universityMatch = getStringMatchScore(query, university);
                
                          // Calculate a total match score by averaging the match scores
                          final totalMatchScore = (nameMatch + majorMatch + universityMatch) / 3.0;
                
                          return {
                'data': doc,
                'matchScore': totalMatchScore,
                          };
                        })
                        .toList()
                        ..sort((a, b) => (b['matchScore']! as double).compareTo(a['matchScore']! as double));
                
                    // Now, `filteredUsers` is sorted by the best match
                    return ListView.builder(
                  itemCount: filteredUsers.length,
                  itemBuilder: (ctx, index) {
                    final doc = filteredUsers[index]['data'] as DocumentSnapshot;
                    final studyBuddy = doc.data() as Map<String, dynamic>;
                
                    return buildBuddyTile(
                      studyBuddy['name'] ?? '',
                      studyBuddy['major'] ?? '',
                      studyBuddy['university'] ?? '',
                      studyBuddy['uid'] ?? '',
                      context,
                    );
                  },
                );
                
                  },
                )
              :            
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .where('uid', isNotEqualTo: FirebaseAuth.instance.currentUser?.uid)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
              
                  if (snapshot.hasError) {
                    return Center(
                      child: Text(
                        'Error: ${snapshot.error}',
                        style: TextStyle(color: Colors.white),
                      ),
                    );
                  }
              
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Text(
                        'No study buddies available.',
                        style: TextStyle(color: Colors.white),
                      ),
                    );
                  }
              
                  final studyGroups = snapshot.data!.docs;
                  // Fetch current user data for comparison
                  return FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance
                        .collection('users')
                        .doc(FirebaseAuth.instance.currentUser?.uid)
                        .get(),
                    builder: (context, currentUserSnapshot) {
                      if (!currentUserSnapshot.hasData) {
                        return Center(child: CircularProgressIndicator());
                      }
                      final currentUser = currentUserSnapshot.data!;
              
                      final currentMajor = currentUser['major'];
                      final currentUniversity = currentUser['university'];
                      // Sort the studyGroups based on similarity
                      studyGroups.sort((a, b) {
                        int getPriority(QueryDocumentSnapshot doc) {
              final major = doc['major'];
              final university = doc['university'];
              
              if (major == currentMajor && university == currentUniversity) return 2;
              if (major == currentMajor || university == currentUniversity) return 1;
              return 0;
                        }
              
                        return getPriority(b).compareTo(getPriority(a));
                      });
              
                      return ListView.builder(
                        itemCount: studyGroups.length,
                        itemBuilder: (ctx, index) {
              final studyBuddy = studyGroups[index];
              print('STUDY');
              return buildBuddyTile(
                studyBuddy['name'],
                studyBuddy['major'],
                studyBuddy['university'],
                studyBuddy['uid'],
                context,
              );
                        },
                      );
                    },
                  );
                },
              )),
            )
          ],
        ),
      ),
    );
  }

  Widget buildBuddyTile(String name, String major, String university,String uid,context) {
    print(uid);
    return GestureDetector(
      onTap: () {
         Navigator.push(
          context, MaterialPageRoute(builder: (context) => ProfilePage(uid: uid)));
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 10),
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.orange,
              child: Text(name[0].toUpperCase(),style: TextStyle(color: Colors.black),),
            ),
            SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                Text("Major: $major", style: TextStyle(color: Colors.grey)),
                Text("University: $university", style: TextStyle(color: Colors.grey)),
      
              ],
            ),
          ],
        ),
      ),
    );
  }
}
