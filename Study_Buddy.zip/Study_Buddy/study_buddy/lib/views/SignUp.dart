import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:study_buddy/views/Login.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(SignUpApp());
}

class SignUpApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SignUpScreen(),
    );
  }
}

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _majorController = TextEditingController();
  final TextEditingController _uniController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  File? _profileImage;

  final ImagePicker _picker = ImagePicker();
  Future<void> _pickProfileImage() async {
      final XFile? pickedImage = await _picker.pickImage(source: ImageSource.gallery);
      if (pickedImage != null) {
        setState(() {
          _profileImage = File(pickedImage.path);
        });
      }
    }
  void _signUp() async {
     if (_nameController.text.trim().isEmpty ||
      _emailController.text.trim().isEmpty ||
      _phoneController.text.trim().isEmpty || _majorController.text.trim().isEmpty|| _uniController.text.trim().isEmpty ||
      _passwordController.text.trim().isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Please fill in all fields.")),
    );
    return; // Exit function if any field is empty
  }
    try {
      
    UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
    final FirebaseStorage storage = FirebaseStorage.instance;

  String uid = userCredential.user!.uid;
  // String profilePicName = 'profile_pics/${_emailController.text.trim()}.jpg'; // Use UID for the filename
  //     UploadTask profileUploadTask = storage.ref(profilePicName).putFile(_profileImage!);
  //     TaskSnapshot profileSnapshot = await profileUploadTask;
  //     String profileImageUrl = await profileSnapshot.ref.getDownloadURL();

    // Store user details in Firestore under "users" collection
    await FirebaseFirestore.instance.collection("users").doc(uid).set({
      "uid": uid,
      "name": _nameController.text.trim(),
      "phone": _phoneController.text.trim(),
      "email":_emailController.text.trim(),
      "aboutMe":"No info added",
      "major": _majorController.text.trim(),
      "university": _uniController.text.trim()

    });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Sign Up Successful!")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Sign Up Failed: ${e.toString()}")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(
                    Icons.accessibility_new,
                    color: Colors.orange,
                    size: 60,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  "SignUp",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  "Create an account it's freeeeeee!",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 16,
                  ),
                ),
                SizedBox(height: 5),
                buildTextField("Name", _nameController, false),
                buildTextField("Phone Number", _phoneController, false),
                buildTextField("Email", _emailController, false),
                buildTextField("Password", _passwordController, true),
                buildTextField("Major", _majorController, false),
                buildTextField("University", _uniController, false),
                // SizedBox(height: 20),
                // Center(
                //   child: Container(
                //     height: height*0.05,
                //     width: width*0.3,
                //     decoration: BoxDecoration(color: Colors.orange,borderRadius: BorderRadius.circular(10)),
                //     child: TextButton(
                //       onPressed: _pickProfileImage,
                //       child: FittedBox(child: Text('Upload Profile Picture',style: TextStyle(color: Colors.white),)),
                //     ),
                //   ),
                // ),
                SizedBox(height: 5),
            
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: EdgeInsets.symmetric(horizontal: 100, vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: _signUp,
                    child: Text("Create Account"),
                  ),
                ),
                SizedBox(height: 20),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an account ? ",
                        style: TextStyle(color: Colors.white70),
                      ),
                      Container(
                    width: width* 0.3,
                     child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white, // Set background color to black
                        foregroundColor: Colors.white, // Set text color to white for contrast
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: () {
                         Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => LogInScreen()));
                      },
                      child: FittedBox(
                        child: Text(
                        "LogIn",
                        style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                        ),
                                            ),
                      ),
                   )),
                
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller, bool isPassword) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(color: Colors.white70),
          ),
          SizedBox(height: 5),
          TextField(
            controller: controller,
            obscureText: isPassword,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: label,
              hintStyle: TextStyle(color: Colors.white54),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.orange),
                borderRadius: BorderRadius.circular(5),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.orange, width: 2),
                borderRadius: BorderRadius.circular(5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
