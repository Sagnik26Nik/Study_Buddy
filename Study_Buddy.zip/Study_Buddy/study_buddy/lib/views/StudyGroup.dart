import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:study_buddy/views/GroupMembers.dart';
import 'package:timeago/timeago.dart' as timeago;

class StudyGroupPage extends StatefulWidget {
  final String studyGroupId; // ID of the selected study group
  final String groupName;
  StudyGroupPage({required this.studyGroupId,required this.groupName});

  @override
  _StudyGroupPageState createState() => _StudyGroupPageState();
}

class _StudyGroupPageState extends State<StudyGroupPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _questionController = TextEditingController();
  final TextEditingController replyController = TextEditingController();

  var toggleDropDown;
  var topicId;
  Future<void> _askQuestion(String topicId) async {
    String question = _questionController.text.trim();
    if (question.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Please enter a question'),
        backgroundColor: Colors.red,
      ));
      return;
    }

    // Add question to Firestore under the respective topic's messages collection
    try {
      await _firestore
          .collection('StudyGroups')
          .doc(widget.studyGroupId)
          .collection('topics')
          .add({
        'message': question,
        'createdAt': FieldValue.serverTimestamp(),
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Question posted'),
        backgroundColor: Colors.green,
      ));
      // Clear the question input after posting
      _questionController.clear();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error posting question: $e'),
        backgroundColor: Colors.red,
      ));
    }
  }

  Future<void> _toggleDropdown(String topicId,int index) async {
    setState(() {
      if (toggleDropDown == index)
      {
        toggleDropDown = -1;
        topicId = '-';
      }
      else{
      topicId = topicId;
      toggleDropDown = index;
      }
      // Toggle dropdown for showing/hiding messages (optional)
    });
  }
  void _showJoinGroupDialog(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,  // Prevent tapping outside to dismiss
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: Colors.white,  // Set background color to white
        title: Text(
          'Join the Group',
          style: TextStyle(color: Colors.black),  // Title color
        ),
        content: Text(
          'To ask a question or reply, you need to join the group.',
          style: TextStyle(color: Colors.black),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () async{
 String? uid = FirebaseAuth.instance.currentUser?.uid;
      var details = await _firestore.collection('user').doc(uid).get();

      await FirebaseFirestore.instance
          .collection('StudyGroups')
          .doc(widget.studyGroupId) // Using your study group ID
          .collection('members') // Inside the "members" collection
          .doc(uid) // Using the user's uid as the document ID
          .set({
            "name":details['name'],
            "university":details['university']
            ,"major":details['major'],
            "uid":uid,
                        "imageUrl":details['imageUrl']


          });              // Handle "Join Group" action
              Navigator.of(context).pop();
              // Implement your "Join Group" logic here
               ScaffoldMessenger.of(context).showSnackBar(
                                                    SnackBar(content: Text("Group joined")),
                                                  );
  }
            ,
            child: Text(
              'Join Group',
              style: TextStyle(color: Colors.orange),  // Button color
            ),
          ),
          TextButton(
            onPressed: () {
              // Handle "Cancel" action
              Navigator.of(context).pop();
            },
            child: Text(
              'Cancel',
              style: TextStyle(color: Colors.orange),  // Button color
            ),
          ),
        ],
      );
    },
  );
}
String formatTimeAgo(DateTime dateTime) {
  // Get the "time ago" format using the timeago package
  String timeAgo = timeago.format(dateTime);

  // Check for months
  if (timeAgo.contains('month') || timeAgo.contains('months')) {
    timeAgo = timeAgo.replaceAll(RegExp(r'\bmonths?\b'), 'mo');
  }
  
  // Check for weeks
  else if (timeAgo.contains('week') || timeAgo.contains('weeks')) {
    timeAgo = timeAgo.replaceAll(RegExp(r'\bweeks?\b'), 'w');
  }

  // Check for days
  else if (timeAgo.contains('day') || timeAgo.contains('days')) {
    timeAgo = timeAgo.replaceAll(RegExp(r'\bdays?\b'), 'd');
  }

  // Check for hours
  else if (timeAgo.contains('hour') || timeAgo.contains('hours')) {
    timeAgo = timeAgo.replaceAll(RegExp(r'\bhours?\b'), 'h');
  }

  // Check for minutes
  else if (timeAgo.contains('minute') || timeAgo.contains('minutes')) {
    timeAgo = timeAgo.replaceAll(RegExp(r'\bminutes?\b'), 'm');
  }

  // Check for seconds
  else if (timeAgo.contains('second') || timeAgo.contains('seconds')) {
    timeAgo = timeAgo.replaceAll(RegExp(r'\bseconds?\b'), 's');
  }

  return timeAgo; // Return the formatted time ago string
}
var showEvents = false;
TextEditingController _nameController = TextEditingController();
TextEditingController _detailsController = TextEditingController();
TextEditingController _dateController = TextEditingController();
TextEditingController _timeController = TextEditingController();
var createEvent=false;
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar:AppBar(
    backgroundColor: Colors.orange,
    centerTitle: true,  // Ensures title is centered in the AppBar
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Text(
      widget.groupName,
      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
      overflow: TextOverflow.ellipsis,  // Handles text overflow
      maxLines: 1,  // Ensures the text doesn't exceed one line
    ),
    IconButton(onPressed: ()
    {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => MembersPage(studyGroupId: widget.studyGroupId,)));
    }, icon: Icon(Icons.people_alt_outlined),color: Colors.black,)
    ])
  
  ),


      body: 
      SingleChildScrollView(
        child: Column(
          children: [
            Center(child: TextButton(onPressed: ()
            {
              setState(() {
                  showEvents = !showEvents;
        
              });
            }, child: Text(showEvents==true?'Close events':'View events',style: TextStyle(color: Colors.orange),)),)
            ,
        
            if(showEvents==true)
            Container(
              width: width*0.9,
              height: height*0.3,
              padding: EdgeInsets.all(16.0),
              child: StreamBuilder<QuerySnapshot>(
                stream: _firestore
                    .collection('StudyGroups')
                    .doc(widget.studyGroupId)
                    .collection('events')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
            
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}',style: TextStyle(color: Colors.white),));
                  }
            
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text('No Events available.',style: TextStyle(color: Colors.white),));
                  }
            
                  final events = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: events.length,
                    itemBuilder: (ctx, index) {
                      var event = events[index];
                      String eventId = event.id;
                      String eventName = event['Title'] ?? 'No Title';
                      String eventDetails = event['Details'] ?? 'No Title';
                      String eventDate = event['eventDate']??'No Date';
                      String eventTime = event['eventTime']??'No Date';
                      final a = event['createdAt'] as Timestamp?;
                      var time;
                      if (a != null) {
                            time  = timeago.format(a.toDate());
                            } else {
                              time = 'Please wait...'; // or any fallback text
                            }
                      // Get the "time ago" format
            
                      return Card(
                        color: Colors.orange[700],
                        margin: EdgeInsets.symmetric(vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                              Container(
                                width: width*0.6,
                                child: Text(
                                  eventName,
                                  style: TextStyle(color: Colors.white, fontSize: 18),
                                ),
                              ),
                             Container(
                              width: width*0.15,
              alignment: Alignment.centerRight, // or Alignment.topRight
              child: FittedBox(
                child: Text(
            time,
                 
            style: TextStyle(color: Colors.white),
                ),
              ),
            )
                                ]),
                 Container(
                              width: width*0.6,
              child: FittedBox(
                child: Text(
            'Date: ${eventDate}, Time: ${eventTime}',
                 
            style: TextStyle(color: Colors.white),
                ),
              ),
            ),
             Container(
                              width: width*0.6,
              child: Text(
                        'Details: ${eventDetails}',
               
                        style: TextStyle(color: Colors.white),
              ),
            )                                
        
                            ])));
                    });
                    }
                    )),
        
            Container(child: TextButton(onPressed: ()
            {
              setState(() {
                
               createEvent = !createEvent;
                           });
        
            }, child: Text(createEvent==true? 'Close':'Create Event'),)),
        
            if(createEvent==true)
            buildTextField("Event Name", _nameController, false,context),
            if(createEvent==true)
            buildTextField("Event Date", _dateController, false,context),
            if(createEvent==true)
            buildTextField("Event Time", _timeController, false,context),
            if(createEvent==true)
            buildTextField("Event Details", _detailsController, false,context),
        
            if(createEvent==true)
            TextButton(onPressed: ()
            async{
              try{
                final title = _nameController.text.trim();
          final date = _dateController.text.trim();
          final time = _timeController.text.trim();
          final details = _detailsController.text.trim();
        
          // Basic validation
          if (title.isEmpty || date.isEmpty || time.isEmpty || details.isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please fill in all fields")),
            );
            return;
          }
                  await FirebaseFirestore.instance.collection("StudyGroups").doc(widget.studyGroupId).collection('events').add({
        "Title": _nameController.text.trim(),
        "eventDate": _dateController.text.trim(),
        "eventTime":_timeController.text.trim(),
        "Details": _detailsController.text.trim(),
        "createdAt":FieldValue.serverTimestamp(),
            });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Event Added")),
        );
            } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Sign Up Failed: ${e.toString()}")),
        );
            }
            _nameController.clear();
            _detailsController.clear();
            _timeController.clear();
            _dateController.clear();
            }, child: Text('Submit')),
            Container(
              width: width*0.9,
              height: height*0.7,
              padding: EdgeInsets.all(16.0),
              child: StreamBuilder<QuerySnapshot>(
                stream: _firestore
                    .collection('StudyGroups')
                    .doc(widget.studyGroupId)
                    .collection('topics')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
            
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}',style: TextStyle(color: Colors.white),));
                  }
            
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text('No topics available.',style: TextStyle(color: Colors.white),));
                  }
            
                  final topics = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: topics.length,
                    itemBuilder: (ctx, index) {
                      var topic = topics[index];
                      String topicId = topic.id;
                      String topicName = topic['message'] ?? 'No Title';
                      final a1 = topic['createdAt'] as Timestamp?;
                      var time1;
                      if (a1 != null) {
                            time1  = timeago.format(a1.toDate());
                            } else {
                              time1 = 'Please wait...'; // or any fallback text
                            }
                      // Get the 
            
                      // Get the "time ago" format
            
                      return Card(
                        color: Colors.orange[700],
                        margin: EdgeInsets.symmetric(vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                              Container(
                                width: width*0.6,
                                child: Text(
                                  topicName,
                                  style: TextStyle(color: Colors.white, fontSize: 18),
                                ),
                              ),
                             Container(
                              width: width*0.15,
              alignment: Alignment.centerRight, // or Alignment.topRight
              child: FittedBox(
                child: Text(
            time1,
                 
            style: TextStyle(color: Colors.white),
                ),
              ),
            )
            
                              ]),
                              SizedBox(height: 8),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black,
                                  foregroundColor: Colors.orange,
                                ),
                                onPressed: (){
            
                                   _toggleDropdown(topicId,index);
                                },
                                child: Text(
                                  toggleDropDown==index?'Close Messages':'View Messages',
                                  style: TextStyle(fontSize: 14),
                                ),
                              ),
                              SizedBox(height: 8),
                              if(toggleDropDown==index)
                              StreamBuilder<QuerySnapshot>(
                                stream: _firestore
                                    .collection('StudyGroups')
                                    .doc(widget.studyGroupId)
                                    .collection('topics')
                                    .doc(topicId)
                                    .collection('messages')
                                    .orderBy('createdAt', descending: true)
                                    .snapshots(),
                                builder: (context, messagesSnapshot) {
                                  print(topicId);
                                  if (messagesSnapshot.connectionState == ConnectionState.waiting) {
                                    return Center(child: CircularProgressIndicator());
                                  }
            
                                  if (messagesSnapshot.hasError) {
                                    return Center(child: Text('Error: ${messagesSnapshot.error}'));
                                  }
            
                                  
                                  
            
                                  final messages = messagesSnapshot.data!.docs;
                                  return Container(
                                    height: messages.isEmpty? null: height*0.3,
                                    width: width*0.9,
                                    child: SingleChildScrollView(
                                      child: Column(
            
                                        children: [
                                       
                                          Container(
                                            height: height*0.1,
                                            width: width*0.9,
                                            child: Row(children: [
                                              Container(
                                                width: width*0.5,
                                                child: TextField(
                                                    controller: replyController,
                                                    style: TextStyle(color: Colors.white),
                                                    decoration: InputDecoration(
                                                      hintText: 'Enter reply',
                                                      hintStyle: TextStyle(color: Colors.white54),
                                                      enabledBorder: OutlineInputBorder(
                                                        borderSide: BorderSide(color: Colors.orange),
                                                        borderRadius: BorderRadius.circular(5),
                                                      ),
                                                      focusedBorder: OutlineInputBorder(
                                                        borderSide: BorderSide(color: Colors.orange, width: 2),
                                                        borderRadius: BorderRadius.circular(5),
                                                      ),
                                                    ),
                                                  ),
                                              ),
                                              SizedBox(width: 10,),
                                              ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black, // Background color
                foregroundColor: Colors.orange, // Text color
                shape: RoundedRectangleBorder(  // Square shape (no border radius)
            borderRadius: BorderRadius.circular(5),
                )),
                                                onPressed: ()
                                              async{
            
              DocumentSnapshot snapshot = await FirebaseFirestore.instance
            .collection('StudyGroups')
            .doc(widget.studyGroupId)
            .collection('members')
            .doc(FirebaseAuth.instance.currentUser?.uid)
            .get();
              
              if (!snapshot.exists) {
                _showJoinGroupDialog(context);
               
              } else 
              {
                                                   if (replyController.text.trim().isEmpty){
                                                        ScaffoldMessenger.of(context).showSnackBar(
                                                          SnackBar(content: Text("Please fill in all fields.")),
                                                        );
                                                        return; // Exit function if any field is empty
                                                      }
                                                        try {
                                                          var uid = FirebaseAuth.instance.currentUser?.uid;
                                                         final userDoc = await FirebaseFirestore.instance
                                                              .collection('users')
                                                              .doc(uid)
                                                              .get();
                                                        // Store user details in Firestore under "users" collection
                                                        await FirebaseFirestore.instance.collection("StudyGroups").doc(widget.studyGroupId).collection('topics').doc(topicId).collection('messages').add({
                                                          "uid": uid,
                                                          "name": userDoc['name'],
                                                          "message": replyController.text.trim(),
                                                          "createdAt": FieldValue.serverTimestamp(),
                                            
                                                        });
                                            
                                                          ScaffoldMessenger.of(context).showSnackBar(
                                                            SnackBar(content: Text("Reply added!")),
                                                          );
                                                        } catch (e) {
                                                          ScaffoldMessenger.of(context).showSnackBar(
                                                            SnackBar(content: Text("Failed: ${e.toString()}")),
                                                          );
                                                        }
              }
                                              }, child: Text('Reply'))
                                            
                                            ],),
                                          ),
                                          SizedBox(height: 10,),
                                        if (!messagesSnapshot.hasData || messagesSnapshot.data!.docs.isEmpty)
                                        Text('No messages yet.')
                                        else
                                        ...messages.map((message) {
                                          final a = message['createdAt'] as Timestamp?;
                                          var time;
                                          if (a != null) {
                                                 time  = timeago.format(a.toDate());
                                                } else {
                                                  time = 'Please wait...'; // or any fallback text
                                                }
                                          return Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                          Row(children: [ Container(child: Text('• ${message['name']}',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)),
                                          SizedBox(width: width*0.1,),
                                          Container(child: Text(time))
                                          
                                          ]
                                          ),
                                          SizedBox(height: 5,),
                                          Row(children: [
                                            Text('   -'),
                                          Container(child: Text(' ${message['message']}'),
                                          ),]),
                                          SizedBox(height: 10,)
            
                                          ]);
                                          
                                        }).toList(),
                                        ]
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.orange,
        child: Icon(Icons.question_answer, color: Colors.black),
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text("Ask a Question",style: TextStyle(color: Colors.orange,fontWeight: FontWeight.bold),),
                content: TextField(
                  controller: _questionController,
                  decoration: InputDecoration(hintText: "Enter your question here"),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text("Cancel",style: TextStyle(color: Colors.orange,fontWeight: FontWeight.bold),),
                  ),
                  TextButton(
                    onPressed: () async{

  DocumentSnapshot snapshot = await FirebaseFirestore.instance
      .collection('StudyGroups')
      .doc(widget.studyGroupId)
      .collection('members')
      .doc(FirebaseAuth.instance.currentUser?.uid)
      .get();
  
  if (!snapshot.exists) {
    Navigator.of(context).pop();

    _showJoinGroupDialog(context);
   
  } else 
  {
                      
                        // Post the question to Firestore (topic ID should be passed in a real implementation)
                        _askQuestion('topicId'); // Pass the correct topicId here
                        Navigator.of(context).pop();
                  _questionController.clear();
                    }
            },
                    child: Text("Ask",style: TextStyle(color: Colors.orange,fontWeight: FontWeight.bold),),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
 Widget buildTextField(String label, TextEditingController controller, bool isPassword,context) {
  double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Padding(
      
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(color: Colors.white70),
          ),
          SizedBox(height: 5),
          Container(
            width: width*0.6,
            height: height*0.07,
            child: TextField(
              controller: controller,
              obscureText: isPassword,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: label,
                hintStyle: TextStyle(color: Colors.white54),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.orange),
                  borderRadius: BorderRadius.circular(5),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.orange, width: 2),
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
            ),
          ),
        ],
      ),
    );

}
