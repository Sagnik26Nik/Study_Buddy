import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:study_buddy/views/Profile.dart';

class ChatPage extends StatefulWidget {

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _messageController = TextEditingController();
  var chatUid=null;
  var recname;
  final String _userId = FirebaseAuth.instance.currentUser!.uid;  // Replace with the actual user UID

  // Function to send a message
  Future<void> sendMessage() async {
    if (_messageController.text.isNotEmpty) {
      await _firestore.collection('users')
          .doc(_userId)
          .collection('conversations').doc(chatUid).collection('messages')
          .add({
        'senderId': _userId,
        'message': _messageController.text,
        'timestamp': FieldValue.serverTimestamp(),
      });
     await _firestore.collection('users')
          .doc(chatUid)
          .collection('conversations').doc(_userId).collection('messages')
          .add({
        'senderId': _userId,
        'message': _messageController.text,
        'timestamp': FieldValue.serverTimestamp(),
      });
      _messageController.clear();  // Clear the input field
    }
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,  // Background color
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(
          "Chat",
          style: TextStyle(color: Colors.orange),
        ),
      ),
      body: Column(
        children: [
          Row(
            children: [
              Container(
                height: height*0.5,
                width: width*0.3,
                child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore
                      .collection('users')
                      .doc(_userId)
                      .collection('conversations')
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }
                            
                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(
                        child: Text(
                          "No messages yet",
                          style: TextStyle(color: Colors.white),
                        ),
                      );
                    }
                            
                    var chats = snapshot.data!.docs;
                            
                    return ListView.builder(
                      itemCount: chats.length,
                      itemBuilder: (context, index) {
                        var chat = chats[index];
                          
                        return Container(
                          margin: EdgeInsets.all(8),
                          width: width*0.3,
                          height: height*0.1,
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(5)
                          ),
                          child:  GestureDetector(
                            onTap: ()
                            {
                              setState(() {
                                chatUid = chat['uid'];
                                recname = chat['name'];
                              });
                            },
                            child: Row(children: [
                              Padding(
                                padding: const EdgeInsets.all(3.0),
                                child: CircleAvatar(
                                ),
                              ),
                              SizedBox(width: width*0.05,),
                              Container(
  width: width * 0.1,
  child: Text(
    chat['name'],
    style: TextStyle(color: Colors.white),
    overflow: TextOverflow.ellipsis, // This truncates the text with "..."
    maxLines: 1,                      // Only one line allowed
    softWrap: false,                 // Prevents wrapping to a new line
  ),
)

                            ],),
                          ),
                        );
                      });
                      }),
              ),
              if(chatUid!=null)
              Container(
                width: width*0.68,
                height: height*0.80,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Colors.white,

                ),
                child: Column(children: [ 
                  GestureDetector(
                    onTap: () {
                      Navigator.pushReplacement(
                        context, MaterialPageRoute(builder: (context) => ProfilePage(uid: chatUid,)));
                    },
                    child: Container(
                      width: width*0.68,
                      height: height*0.07,
                      decoration: BoxDecoration(
                        color: Colors.blueGrey,
                      ),
                      child: Row(children: [
                             Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: CircleAvatar(
                                    ),
                                  ),
                                  SizedBox(width: width*0.05,),
                                  Container(
                                          width: width * 0.5,
                                          child: Text(
                                            recname,
                                            style: TextStyle(color: Colors.white),
                                            overflow: TextOverflow.ellipsis, // This truncates the text with "..."
                                            maxLines: 1,                      // Only one line allowed
                                            softWrap: false,                 // Prevents wrapping to a new line
                                          ),
                                        )
                      
                      ],),
                    ),
                  ),
                  Container(
                    height: height*0.7,
                    child: StreamBuilder<QuerySnapshot>(
                    stream: _firestore
                        .collection('users')
                        .doc(_userId)
                        .collection('conversations').doc(chatUid).collection('messages')
                        .orderBy('timestamp')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      }
                            
                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return Center(
                          child: Text(
                            "No messages yet",
                            style: TextStyle(color: Colors.white),
                          ),
                        );
                      }
                            
                      var messages = snapshot.data!.docs;
                            
                      return ListView.builder(
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          var message = messages[index];
                          bool isSender = message['senderId'] == _userId;
                            
                          return Align(
                            alignment: isSender
                                ? Alignment.centerRight  // Outgoing message on the right
                                : Alignment.centerLeft, // Incoming message on the left
                            child: Container(
                              margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                              padding: EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: isSender ? Colors.orange : Colors.grey[800],
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                message['message'],
                                style: TextStyle(
                                  color: isSender ? Colors.black : Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                                    ),
                  ),
                ])
              ),
            ]),
              if(chatUid!=null)
              // Message input field
              Container(
                margin: EdgeInsets.only(top: height*0.03),
                width: width*0.95,
                height: height*0.07,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(5)
                ),
                child: Row(
                  children: [
                    Container(
                      width: width*0.75,
                      height: height*0.07,
                      child: TextField(
                        controller: _messageController,
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Type a message...',
                          hintStyle: TextStyle(color: Colors.white60),
                          filled: true,
                          fillColor: Colors.black45,
                         
                        ),
                      ),
                    ),
                    Container(
                      width: width*0.12,
                      margin: EdgeInsets.only(left: width*0.05),
                      child: IconButton(
                        splashRadius: 40,
                        onPressed: sendMessage,
                        icon: Icon(Icons.send, color: Colors.orange),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
      
    );
  }
}
