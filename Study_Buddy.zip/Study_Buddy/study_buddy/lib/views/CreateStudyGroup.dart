import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CreateStudyGroupPage extends StatefulWidget {
  @override
  _CreateStudyGroupPageState createState() => _CreateStudyGroupPageState();
}

class _CreateStudyGroupPageState extends State<CreateStudyGroupPage> {
  final TextEditingController _groupNameController = TextEditingController();
  final TextEditingController _courseCodeController = TextEditingController();
  final TextEditingController _numModulesController = TextEditingController();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> _createStudyGroup() async {
    String groupName = _groupNameController.text.trim();
    String courseCode = _courseCodeController.text.trim();
    int numModules = int.tryParse(_numModulesController.text.trim()) ?? 0;

    if (groupName.isEmpty || courseCode.isEmpty || numModules <= 0) {
      // Show error message if fields are not valid
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Please fill all fields correctly'),
        backgroundColor: Colors.red,
      ));
      return;
    }

    // Create a new study group document in Firestore
    try {
      await _firestore.collection('StudyGroups').add({
        'groupName': groupName,
        'courseCode': courseCode,
        'numModules': numModules,
      });

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Study Group Created Successfully'),
        backgroundColor: Colors.green,
      ));

      // Optionally, navigate to another page or reset form
      // Navigator.pop(context);
    } catch (e) {
      // Handle any errors
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error creating study group: $e'),
        backgroundColor: Colors.red,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.orange),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Text("Create StudyGroup", style: TextStyle(color: Colors.white, fontSize: 18)),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTextField("Group Name", _groupNameController),
            _buildTextField("Course Code", _courseCodeController),
            _buildTextField("Number of Modules", _numModulesController, keyboardType: TextInputType.number),
            SizedBox(height: 20),
            _buildCreateGroupButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {TextInputType keyboardType = TextInputType.text}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: Colors.white, fontSize: 16)),
        SizedBox(height: 5),
        TextField(
          controller: controller,
          style: TextStyle(color: Colors.white),
          keyboardType: keyboardType,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.grey[900],
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(5)),
          ),
        ),
        SizedBox(height: 10),
      ],
    );
  }

  Widget _buildAddModulesButton() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(10),
      ),
      child: TextButton(
        onPressed: () {},
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Add Modules", style: TextStyle(color: Colors.white, fontSize: 16)),
            Icon(Icons.arrow_forward, color: Colors.orange),
          ],
        ),
      ),
    );
  }

  Widget _buildCreateGroupButton() {
    return Container(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.orange,
          foregroundColor: Colors.black,
          padding: EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
        ),
        onPressed: _createStudyGroup,
        child: Text("Create Group", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
