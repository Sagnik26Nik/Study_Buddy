import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:study_buddy/views/CreateStudyGroup.dart';
import 'package:study_buddy/views/FindStudyBuddies.dart';
import 'package:study_buddy/views/FindStudyGroups.dart';
import 'package:study_buddy/views/Profile.dart';
import 'package:study_buddy/views/StudyGroup.dart';



class DashboardPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 40),
          
              Center(
                child: CircleAvatar(
                  backgroundColor: Colors.orange,
                  radius: width*0.1,
                  child: FutureBuilder<DocumentSnapshot>(
                        future: FirebaseFirestore.instance
                            .collection('users')
                            .doc(FirebaseAuth.instance.currentUser?.uid)
                            .get(),
                        builder: (context, currentUserSnapshot) {
                          if (!currentUserSnapshot.hasData) {
                            return Center(child: CircularProgressIndicator());
                          }
                          final currentUser = currentUserSnapshot.data!;
                          return Text(
                    currentUser['name'][0].toUpperCase(),
                    style: TextStyle(color: Colors.black, fontSize: width*0.1),
                  );
                        })
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  alignment: WrapAlignment.center,
                 children: [
                  _buildButton(
                    'Create StudyGroup',
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => CreateStudyGroupPage()),
                    ),
                  ),
                  _buildButton(
                    'Find StudyBuddies',
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FindStudyBuddies()),
                    ),
                  ),
                  _buildButton(
                    'Find StudyGroups',
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FindStudyGroups()),
                    ),
                  ),
                  _buildButton(
                    'Profile',
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ProfilePage(uid: null)),
                    ),
                  ),
                ],
                ),
              ),
              SizedBox(height: 20),
          
              _buildSectionTitle('Your StudyGroups'),
              SizedBox(height: 10),
          
              SizedBox(
                height: height*0.2, // Adjust height for the horizontal scroll
                child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('StudyGroups')
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(child: CircularProgressIndicator());
                        }
                    
                        if (snapshot.hasError) {
                          return Center(
                            child: Text(
                              'Error: ${snapshot.error}',
                              style: TextStyle(color: Colors.white),
                            ),
                          );
                        }
                    
                        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                          return Center(
                            child: Text(
                              'No study groups yet.',
                              style: TextStyle(color: Colors.white),
                            ),
                          );
                        }
                    final studyGroups = snapshot.data!.docs; 
                        return ListView.builder(
                          scrollDirection: Axis.horizontal,
                        itemCount: studyGroups.length,
                        itemBuilder: (ctx, index) {
                          final studyGroup  = studyGroups[index].data();
                          return FutureBuilder<QuerySnapshot>(
                          future: FirebaseFirestore.instance
                              .collection('StudyGroups')
                              .doc(studyGroups[index].id)
                              .collection('members')
                              .get(),
                          builder: (context, memberSnapshots) {
                            var isMember=false;
                            var membersCount=0;
                             if (memberSnapshots.hasData) {
              membersCount = memberSnapshots.data!.docs.length;
          
              isMember = memberSnapshots.data!.docs.any(
                (doc) => doc.id == FirebaseAuth.instance.currentUser?.uid,
              );
              if(isMember)
              {
                return _buildStudyGroupCard(
                      studyGroups[index]['groupName'],
                      studyGroups[index]['courseCode'],
                      membersCount,
                      studyGroups[index].id,
                      width*0.4,
                      context
                    );
              }
              else{
                return Text('');
              }
            }
            return Text('');
                          });});})),
          
              SizedBox(height: 20),
              _buildSectionTitle('Your StudyBuddies'),
              SizedBox(height: 20),
          
              SizedBox(
                height: height*0.2, // Adjust height for the horizontal scroll
                child: StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('users')
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(child: CircularProgressIndicator());
                        }
                    
                        if (snapshot.hasError) {
                          return Center(
                            child: Text(
                              'Error: ${snapshot.error}',
                              style: TextStyle(color: Colors.white),
                            ),
                          );
                        }
                    
                        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                          return Center(
                            child: Text(
                              'No study buddies yet.',
                              style: TextStyle(color: Colors.white),
                            ),
                          );
                        }
                    final studyBuddies = snapshot.data!.docs; 
                        return ListView.builder(
                          scrollDirection: Axis.horizontal,
                        itemCount: studyBuddies.length,
                        itemBuilder: (ctx, index) {
                          return FutureBuilder<QuerySnapshot>(
                          future: FirebaseFirestore.instance
                              .collection('users')
                              .doc(studyBuddies[index].id)
                              .collection('conversations')
                              .get(),
                          builder: (context, memberSnapshots) {
                            var isMember=false;
                            var membersCount=0;
                             if (memberSnapshots.hasData) {
          
              isMember = memberSnapshots.data!.docs.any(
                (doc) => doc.id == FirebaseAuth.instance.currentUser?.uid,
              );
              if(isMember)
              {
                return _buildStudyBuddyCard(
                      studyBuddies[index]['name'],
                      studyBuddies[index]['university'],
                      studyBuddies[index]['major'],
                      studyBuddies[index].id,
                      width*0.4,
                      context
                    );
              }
              else{
                return Text('');
              }
            }
            return Text('');
                          });});})),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildButton(String text,func) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.grey[900],
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
      ),
      onPressed: () {
        func();
      },
      child: Text(text, style: TextStyle(color: Colors.white)),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: EdgeInsets.only(left: 10),
      child: Text(title,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.orange)),
    );
  }

  Widget _buildStudyGroupCard(String name, String members, int score,uid,width,context) {
    return Container(
      width: width,
      margin: EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(10),
      ),
      child: GestureDetector(
        onTap: () {
           Navigator.push(
          context, MaterialPageRoute(builder: (context) => StudyGroupPage(studyGroupId: uid, groupName: name,))); 
        },
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              SizedBox(height: 5),
              Text("Course Code: $members", style: TextStyle(color: Colors.grey)),
              SizedBox(height: 5),
              Text("Members: $score", style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStudyBuddyCard(String name, String uni,String major ,uid, Width,context) {
    return Container(
      width: Width,
      margin: EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(10),
      ),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
          context, MaterialPageRoute(builder: (context) => ProfilePage(uid: uid,))); 
        },
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name.toUpperCase(), style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              SizedBox(height: 5),
              Text("University: $uni", style: TextStyle(color: Colors.grey)),
              SizedBox(height: 5),
              Text("Major: $major", style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}
