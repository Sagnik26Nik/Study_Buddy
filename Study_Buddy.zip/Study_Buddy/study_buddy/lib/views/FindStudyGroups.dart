import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:study_buddy/views/StudyGroup.dart';

class FindStudyGroups extends StatefulWidget {
  @override
  State<FindStudyGroups> createState() => _FindStudyGroupsState();
}

class _FindStudyGroupsState extends State<FindStudyGroups> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  TextEditingController _searchController = TextEditingController();
 double getStringMatchScore(String source, String target) {
  // If either string is empty, there's no match
  if (source.isEmpty || target.isEmpty) return 0.0;

  source = source.toLowerCase();
  target = target.toLowerCase();

  // The longer the common substring, the higher the match score
  int commonChars = 0;

  for (int i = 0; i < source.length; i++) {
    if (target.contains(source[i])) {
      commonChars++;
    }
  }

  // Normalize the score between 0 and 1
  double score = commonChars / source.length;
  return score;
}
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    var showSuggested = false;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.orange),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("Find Study Groups", style: TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Search Study Groups", style: TextStyle(color: Colors.white, fontSize: 18)),
            SizedBox(height: 10),
              Row(children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Container(
                width: width*0.75,
                height: height*0.07,
                child: TextField(
                  style: TextStyle(color: Colors.white),
                  controller: _searchController,
                  decoration: InputDecoration(
                    
                    hintText: "Find your Groups",
                    hintStyle: TextStyle(color: Colors.grey),
                    prefixIcon: Icon(Icons.search, color: Colors.grey),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.all(16),
                  ),
                ),
              ),
            ),
              IconButton(onPressed: ()
              {
                setState(() {
                  
                  showSuggested = false;
                });

              }, icon: Icon(Icons.search,color: Colors.orange,)),
              IconButton(onPressed: ()
              {
                _searchController.clear();
                setState(() {
                  
                showSuggested = true;
                                });

              }, icon: Icon(Icons.cancel,color: Colors.orange,)),
            ]),
            SizedBox(height: 16),
            Text("Suggested", style: TextStyle(color: Colors.white, fontSize: 18)),
            SizedBox(height: 10),
             Container(
              width: width*0.9,
              height: height*0.6,
               child: showSuggested==false?  StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('StudyGroups')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      }
                  
                      if (snapshot.hasError) {
                        return Center(
                          child: Text(
                            'Error: ${snapshot.error}',
                            style: TextStyle(color: Colors.white),
                          ),
                        );
                      }
                  
                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return Center(
                          child: Text(
                            'No study groups available.',
                            style: TextStyle(color: Colors.white),
                          ),
                        );
                      }
                  
                      // Get the search query and convert to lower case
                      final query = _searchController.text.toLowerCase();
                  
                      // Filter users based on the query string match score
                      final filteredUsers = snapshot.data!.docs
                          .map((doc) {
                            final courseCode = doc['courseCode'].toString();
                            final groupName = doc['groupName'].toString();
                  
                            // Calculate a score for each field
                            final nameMatch = getStringMatchScore(query, courseCode);
                            final majorMatch = getStringMatchScore(query, groupName);
                  
                            // Calculate a total match score by averaging the match scores
                            final totalMatchScore = (nameMatch + majorMatch) / 2.0;
                  
                            return {
                  'data': doc,
                  'matchScore': totalMatchScore,
                            };
                          })
                          .toList()
                          ..sort((a, b) => (b['matchScore']! as double).compareTo(a['matchScore']! as double));
                  
                      // Now, `filteredUsers` is sorted by the best match
                      return ListView.builder(
                      itemCount: filteredUsers.length,
                      itemBuilder: (ctx, index) {
                        final doc = filteredUsers[index]['data'] as DocumentSnapshot;
                        final studyGroup = doc.data() as Map<String, dynamic>;
                        String studyGroupId = doc.id;
                        String studyGroupName = studyGroup['groupName'] ?? 'No Name';
                        String description = studyGroup['courseCode'] ?? 'No Description';
               
                        return FutureBuilder<QuerySnapshot>(
                        future: FirebaseFirestore.instance
                            .collection('StudyGroups')
                            .doc(studyGroupId)
                            .collection('members')
                            .get(),
                        builder: (context, memberSnapshot) {
                          int membersCount = 0;
                          if (memberSnapshot.hasData) {
                            membersCount = memberSnapshot.data!.docs.length;
                          }
               
                          return  GestureDetector(
                          onTap: ()
                          {
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>StudyGroupPage(studyGroupId: studyGroupId,groupName: studyGroupName,)));
                          },
                          child: Container(
                            margin: EdgeInsets.only(bottom: 10),
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      studyGroupName,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      "Course Code: $description",
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                    Text(
                                      "Members: $membersCount",
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Icon(Icons.group, color: Colors.orange),
                                    SizedBox(width: 5),
                                    
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                      });
                    }):
             
            StreamBuilder<QuerySnapshot>(
                stream: _firestore.collection('StudyGroups').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text('No study groups available.'));
                  }

                  final studyGroups = snapshot.data!.docs;

                  return ListView.builder(
                    itemCount: studyGroups.length,
                    itemBuilder: (ctx, index) {
                      var studyGroup = studyGroups[index];
                      String studyGroupId = studyGroup.id;
                      String studyGroupName = studyGroup['groupName'] ?? 'No Name';
                      String description = studyGroup['courseCode'] ?? 'No Description';
                      return FutureBuilder<QuerySnapshot>(
                        future: FirebaseFirestore.instance
                            .collection('StudyGroups')
                            .doc(studyGroupId)
                            .collection('members')
                            .get(),
                        builder: (context, memberSnapshot) {
                          int membersCount = 0;
                          if (memberSnapshot.hasData) {
                            membersCount = memberSnapshot.data!.docs.length;
                          }
               
                          return  GestureDetector(
                        onTap: ()
                        {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>StudyGroupPage(studyGroupId: studyGroupId,groupName: studyGroupName,)));
                        },
                        child: Container(
                          margin: EdgeInsets.only(bottom: 10),
                          padding: EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.grey[900],
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    studyGroupName,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    "Course Code: $description",
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  Text(
                                    "Members: $membersCount",
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Icon(Icons.currency_bitcoin, color: Colors.grey),
                                  SizedBox(width: 5),
                                ]
                                  ),
                                ],
                              )));
                    });
                });
                }))
                            ],
                          ),
                        ),
                      );
  }
}
