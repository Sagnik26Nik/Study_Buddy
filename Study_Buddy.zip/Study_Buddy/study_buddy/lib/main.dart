import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:study_buddy/firebase_options.dart';
import 'package:study_buddy/providers/login_provider.dart';
import 'package:study_buddy/views/Chat.dart';
import 'package:study_buddy/views/CreateStudyGroup.dart';
import 'package:study_buddy/views/FindStudyBuddies.dart';
import 'package:study_buddy/views/FindStudyGroups.dart';
import 'package:study_buddy/views/FriendRequests.dart';
import 'package:study_buddy/views/Home.dart';
import 'views/Login.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Required for Firebase

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.android
  );
  runApp( 
    MultiProvider( // or Provider if you only have one
      providers: [
        ChangeNotifierProvider(create: (_) => LoginProvider()),
      ],
      child:
        Directionality( 
    textDirection: TextDirection.ltr,
    child: MaterialApp(home: LogInScreen(),),
  )));
  }

