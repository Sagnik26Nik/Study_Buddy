import 'package:flutter/foundation.dart';

class LoginProvider extends ChangeNotifier {
  var uid;
  void toggleUid(num)
  {
    uid = num;

    notifyListeners();
  }

}
